What is pygame.image.load.convert_alpha?
- allows for transparent pictures to properly render on screen
